﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'cy', {
	copy: 'Hawlfraint &copy; $1. Cedwir pob hawl.',
	dlgTitle: 'Ynghylch CKEditor',
	help: 'Gwirio $1 am gymorth.',
	moreInfo: 'Am wybodaeth ynghylch trwyddedau, ewch i\'n gwefan:',
	title: 'Ynghylch CKEditor',
	userGuide: 'Canllawiau Defnyddiwr CKEditor'
} );
