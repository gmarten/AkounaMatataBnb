﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'vi', {
	copy: 'Bản quyền &copy; $1. Giữ toàn quyền.',
	dlgTitle: 'Thông tin về CKEditor',
	help: 'Kiểm tra $1 để được giúp đỡ.',
	moreInfo: 'Vui lòng ghé thăm trang web của chúng tôi để có thông tin về giấy phép:',
	title: 'Thông tin về CKEditor',
	userGuide: 'Hướng dẫn sử dụng CKEditor'
} );
