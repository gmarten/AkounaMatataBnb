﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'es', {
	bold: 'Negrita',
	italic: 'Cursiva',
	strike: 'Tachado',
	subscript: 'Subíndice',
	superscript: 'Superíndice',
	underline: 'Subrayado'
} );
